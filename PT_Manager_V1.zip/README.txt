PT Manager V1
=============
Progetto SEPARATO dal Diario Allenamento 2.0.

La V1 include:
- dashboard PT
- clienti multipli
- ricerca clienti
- stato scheda: attiva / in scadenza / scaduta
- creazione e modifica cliente
- dettaglio cliente
- scheda / storico / progressi come aree separate
- modifica rapida periodo e nome della scheda
- salvataggio locale nel browser

NOTA:
Questa è una V1 frontend/prototipo. I dati sono salvati nel browser (localStorage), quindi NON sono ancora sincronizzati tra dispositivi.

Architettura prevista per V2:
- autenticazione PT/cliente
- database cloud
- schede sincronizzate
- storico per cliente
- notifiche di scadenza
- aggiornamento automatico della scheda nell'app del cliente
